#pragma once
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cstdint>

#define UINT64 uint64_t

//��Կ�ṹ�壬��¼e��n
class PublicKey
{
public:
	uint64_t nE;
	uint64_t nN;
};

class Paraments
{
public:
	uint64_t d;
	uint64_t n;
	uint64_t e;
};

class RsaParam
{
public:
	uint64_t p;
	uint64_t q;
	uint64_t n;
	uint64_t f;
	uint64_t e;
	uint64_t d;
	uint64_t s;
};

Paraments m_cParament;

//����DES��Կ
void GenerateDesKey(char* randomKey)
{
	std::srand(static_cast<unsigned>(std::time(NULL)));
	for (int i = 0; i < 8; i++)
		randomKey[i] = std::rand() % 93 + 33;
	return;
}

/*
	ģ����
*/
//ģ�˷�������a*b mod n
uint64_t MulMod(uint64_t a, uint64_t b, uint64_t n)
{
	return (a % n) * (b % n) % n;
}

//ģ�����㣬ʹ��ģ�ظ�ƽ���㷨
uint64_t PowMod(uint64_t base, uint64_t pow, uint64_t n)
{
	uint64_t c = 1;
	while (pow)
	{
		while (!(pow & 1))
		{
			pow >>= 1;
			base = MulMod(base, base, n);
		}
		pow--;
		c = MulMod(base, c, n);
	}
	return c;
}

/*
	���Բ���
*/
//Miller-Rabin���Բ����㷨
long RabinMillerKnl(uint64_t n)
{
	uint64_t a, q, k, v;
	q = n - 1;
	k = 0;
	while (!(q & 1))
	{
		++k;
		q >>= 1;
	}
	a = 2 + std::rand() % (n - 3);
	v = PowMod(a, q, n);
	if (v == 1)
		return 1;
	for (int j = 0; j < k; j++)
	{
		uint64_t z = 1;
		for (int w = 0; w < j; w++)
			z *= 2;
		if (PowMod(a, z * q, n) == n - 1)
			return 1;
	}
	return 0;
}

//���ж��Miller-Rabin���Բ��ԣ������ؽ��
long RabinMiller(uint64_t& n, long loop)
{
	for (long i = 0; i < loop; i++)
	{
		if (!RabinMillerKnl(n))
			return 0;
	}
	return 1;
}

//�����������
uint64_t RandomPrime(int bits)
{
	uint64_t base;
	do
	{
		base = static_cast<uint64_t>(1) << (bits - 1);
		base += std::rand() % base;
		base |= 1;
	} while (!RabinMiller(base, 30));
	return base;
}

/*
	���ܽ��ܺ���
*/
//���ܺ���Encry��ͨ����ԿcKey��nSorce���м���
uint64_t Encry(unsigned short nSorce, PublicKey& cKey)
{
	return PowMod(nSorce, cKey.nE, cKey.nN);
}

//���ܺ���Decry
unsigned short Decry(UINT64 nSorce)
{
	UINT64 nRes = PowMod(nSorce, m_cParament.d, m_cParament.n);
	unsigned short* pRes = reinterpret_cast<unsigned short*>(&nRes);
	if (pRes[1] != 0 || pRes[2] != 0 || pRes[3] != 0)
		return 0;
	else
		return pRes[0];
}

/*
	�����Լ��
*/
//ͨ��շת����������Լ��
uint64_t Gcd(uint64_t& p, uint64_t& q)
{
	uint64_t a = p > q ? p : q;
	uint64_t b = p < q ? p : q;
	uint64_t t;
	if (p == q)
	{
		return p;
	}
	else
	{
		while (b)
		{
			a = a % b;
			t = a;
			a = b;
			b = t;
		}
		return a;
	}
}

/*
	˽Կ����
*/
//˽Կ���ɣ���Ҫ����e*d = ��(n)*i+1������
uint64_t Euclid(uint64_t e, uint64_t t_n)
{
	uint64_t Max = 0xffffffffffffffff - t_n;
	uint64_t i = 1;
	while (1)
	{
		if (((i * t_n) + 1) % e == 0)
			return ((i * t_n) + 1) / e;
		i++;
		uint64_t Tmp = (i + 1) * t_n;
		if (Tmp > Max)
			return 0;
	}
	return 0;
}

//��ȡ��Կ
PublicKey GetPublicKey()
{
	PublicKey cTmp;
	cTmp.nE = m_cParament.e;
	cTmp.nN = m_cParament.n;
	return cTmp;
}

//���ɹ�Կ��˽Կ
RsaParam RsaGetParam(void)
{
	RsaParam Rsa = { 0 };
	UINT64 t = 0;
	Rsa.p = RandomPrime(16);
	Rsa.q = RandomPrime(16);
	Rsa.n = Rsa.p * Rsa.q;
	Rsa.f = (Rsa.p - 1) * (Rsa.q - 1);
	do
	{
		Rsa.e = std::rand() % 65536;
		Rsa.e |= 1;
	} while (Gcd(Rsa.e, Rsa.f) != 1);
	Rsa.d = Euclid(Rsa.e, Rsa.f);
	Rsa.s = 0;
	t = Rsa.n >> 1;
	while (t)
	{
		Rsa.s++;
		t >>= 1;
	}
	return Rsa;
}
