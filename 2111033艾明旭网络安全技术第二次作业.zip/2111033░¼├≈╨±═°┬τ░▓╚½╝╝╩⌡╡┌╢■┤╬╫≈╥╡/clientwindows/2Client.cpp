﻿// 2Client.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include <stdio.h>
#include "Client.h"
#include "RSA.h"
#include "DES.h"
#include <math.h>
#include<thread>
#include <windows.h>
#include <iostream>

#pragma comment(lib,"ws2_32.lib")
using namespace std;
void recvFun();											  //接收信息线程
void sendFun();											  //发送信息线程
HANDLE h1, h2;
int m = 0;//控制进程开启关闭的信号量
SOCKET ServerSocket;						  //全局变量，用来通信的socket
extern Paraments m_cParament;
void recvFun()
{
	while (m==0) {
		//利用返回的套接字和客户端通信
		char s[256] = { 0 };
		recv(ServerSocket, s, 256, 0);//接收密文
		if (strlen(s) > 0) {
			memset(op.plaintext, 0, sizeof(op.plaintext));//初始化明文
			int counts = strlen(s);
			int asc_recv = 0;
			int s1[32];
			for (int i = 0; i < counts; i++) {
				int sub = s[i] - 48;
				sub = sub * pow(2, (7 - i % 8));
				asc_recv += sub;
				if (i % 8 == 7) {
					s1[i / 8] = asc_recv;
					asc_recv = 0;
				}
			}
			printf("\nS: 接收客户端的密文:");
			for (int i = 0; i < counts / 8; i++)
				printf("%d,", s1[i]);
			printf("\n");
			//拆解收到的加密信息，转为二进制数组
			op.groupCount = 0;
			//printf("%d\n", strlen(s));
			for (int i = 0; i < strlen(s); i++)
			{
				op.ciphArray[op.groupCount][i % 64] = s[i] - 48;
				if ((i + 1) % 64 == 0)
					op.groupCount++;
			}
			//进行密文的解密
			for (int i = 0; i < op.groupCount; i++)
				op.MakeCiph(op.ciphArray[i], i);
			//输出解密后的明文
			char time[64];
			strcpy(time, op.getTime());
			printf("S: [%s]经过解密后的明文:", time);
			for (int i = 0; i < op.groupCount; i++)
				op.Bit2Char(op.textArray[i]);
			printf("%s\n", op.plaintext);
			// 判断明文是否为"exit"
			if (strcmp(op.plaintext, "exit") == 0) {
				m = 1; // 设置常量m为1
				cout << "关闭";
				CloseHandle(h1);
				CloseHandle(h2);
				shutdown(ServerSocket, 2);
				closesocket(ServerSocket); //关闭套接字
				break; // 退出循环
			}
			cout << endl;
			cout << "请输入明文";
		}
		
	}
	
	return;
}
void sendFun() {
	while (m==0) {
		//如果用户需要继续发送信息，则继续发送
		char plaintext[255] = { 0 }, cipherte[500] = { 0 };
		printf("S: 请输入明文:");
		setbuf(stdin, NULL);
		scanf("%[^\n]s", plaintext);//使得空行代表读取完毕而不是空格
		bool exit = false;
		if (strcmp(plaintext, "exit") == 0)
			exit = true;
		op.MakeData(plaintext);
		int count = 0;
		char time[64];
		strcpy(time, op.getTime());
		printf("S: [%s]向客户端发送密文:", time);
		for (int i = 0; i < op.groupCount; i++)
		{
			for (int j = 0; j < 64; j++)
				cipherte[count++] = op.ciphArray[i][j] + 48;//要加上48
		}
	    cipherte[count] = '\0';
		int ciphertes[32];
		int asc = 0;
		for (int i = 0; i < count; i++) {
			int sub = cipherte[i] - 48;
			sub = sub * pow(2, (7 - i % 8));
			asc += sub;
			if (i % 8 == 7) {
				ciphertes[i / 8] = asc;
				asc = 0;
			}
		}
		for (int i = 0; i < count / 8; i++)
			printf("%d,", ciphertes[i]);
		//发送数据给服务器
		send(ServerSocket, cipherte, strlen(cipherte), 0);
		if (exit) {
			m = 1;
			cout << "关闭";
			CloseHandle(h1);
			CloseHandle(h2);
			shutdown(ServerSocket, 2);
			closesocket(ServerSocket); //关闭套接字
			break; // Exit the loop if "exit" is entered
		}
		cout << endl;
	}
	
	return;
}
int runClient()
{
	//1.加载套接字库
	WORD wVRequested;
	WSADATA wsaData;
	wVRequested = MAKEWORD(2, 2);
	int err = WSAStartup(wVRequested, &wsaData);
	if (err)
		printf("C: 加载socket连接失败\n");
	else
		printf("C: 加载socket连接成功\n");
	//2.创建一个套接字供使用
	ServerSocket = socket(AF_INET, SOCK_STREAM, 0);
	//3.向服务器发出连接请求
	SOCKADDR_IN socksin;//记录服务器端地址
	socksin.sin_family = AF_INET;
	socksin.sin_port = htons(6020);
	socksin.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	int rf = connect(ServerSocket, (SOCKADDR*)&socksin, sizeof(socksin));
	if (rf == SOCKET_ERROR)
		printf("C: 与服务器连接失败\n");
	else
	{
		printf("C: 与服务器连接成功\n");
		char publicKey[100] = { 0 };
		recv(ServerSocket, publicKey, 100, 0);
		printf("C: 从服务器接收到公钥:%s\n", publicKey);
		char sN[100], sE[100];
		int pN = 0, pE = 0;
		bool divide = false;
		for (int i = 0; i < strlen(publicKey); i++)
		{
			if (publicKey[i] == ',') { divide = true; continue; }
			if (!divide)
				sN[pN++] = publicKey[i];
			else
				sE[pE++] = publicKey[i];
		}
		PublicKey rsaPublic;
		rsaPublic.nE = atoi(sE);
		rsaPublic.nN = atoll(sN);
		char encryKey[300];
		char desKey[8] = { 0 }, plaintext[255], ciphenof[500] = { 0 };
		GenerateDesKey(desKey);
		printf("C: 随机生成DES密钥:");
		for (int i = 0; i < 8; i++) {
			printf("%c", desKey[i]);
		}
		printf("\n");
		//scanf("%s", desKey);
		char tempK[8];
		strcpy(tempK, desKey);
		op.MakeKey(tempK);
		int p = 0;
		for (int i = 0; i < 4; i++) {
			int p1 = i * 2, p2 = i * 2 + 1;
			int num1 = int(desKey[p1]);
			int num2 = int(desKey[p2]);
			UINT64 curNum = (num1 << 8) + num2;
			UINT64 encry = Encry(curNum, rsaPublic);
			char cencry[20];
			sprintf(cencry, "%lu", encry);
			strncpy(encryKey + p, cencry, strlen(cencry));
			p += strlen(cencry);
			char divide = ',';
			encryKey[p] = divide;
			p += 1;
		}
		encryKey[p] = '\0';
		//发送加密的DES密钥给给服务器
		printf("C: 向服务器发送加密的DES密钥:%s\n", encryKey);
		send(ServerSocket, encryKey, p, 0);
		while (1)
		{
			//4.接受来自客户端的连接请求
			cout << "已成功连接到服务端" << endl;
			//创建线程后立即运行
			//5.向socket中读取/写入信息
			m = 0;
			h1 = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)sendFun, NULL, 0, NULL); //用于发送的线程
			h2 = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)recvFun, NULL, 0, NULL); //用于接收的线程			
			WaitForSingleObject(h1, INFINITE);
			WaitForSingleObject(h2, INFINITE);
			while (m == 1)
			{
				cout << "关闭";
				shutdown(ServerSocket, 2);
				closesocket(ServerSocket); //关闭套接字				
				CloseHandle(h1);
				CloseHandle(h2);
				return 0;
			}	
		}		
	}
	closesocket(ServerSocket);
	WSACleanup();
	return 0;
}

int main() {
	char mode[10] = { 0 };
	printf("Client:\n");
	while (1) {
		runClient();
		break;
	}
	system("pause");
	return 1;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
