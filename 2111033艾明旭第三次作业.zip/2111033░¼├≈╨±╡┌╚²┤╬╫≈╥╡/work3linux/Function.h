#include <iostream>
#include <string>
#include <string.h>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <streambuf>
using namespace std;
void Help_Message(int argc, char* argv[]); 
void Test_Message(int argc, char* argv[]); 
void Copy_Message(int argc, char* argv[]); 
void Validsure_Message(int argc, char* argv[]); 
void Filesure_Message(int argc, char* argv[]); 